package jspbook2;

public class calculator {
	public int process(int n)
	{
		return n*n*n;
	}
}
